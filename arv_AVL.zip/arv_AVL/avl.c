#include "avl.h" // Arquivo de cabeçalho com as declarações

// Função para alocar um novo nó
tipo_no* aloca_no(char *nome) {
    tipo_no *novo_no = (tipo_no*) malloc(sizeof(tipo_no));
    strcpy(novo_no->nome, nome);
    novo_no->fb = 0;
    novo_no->h = 0;
    novo_no->esq = novo_no->dir = NULL;
    return novo_no;
}

// Calcula a altura de um nó (retorna 0 se for NULL)
int altura_no(tipo_no* no) {
    return no ? no->h : -1;
}

// Calcula o fator de balanceamento
int funcao_balanceamento(tipo_no* no) {
    return altura_no(no->dir) - altura_no(no->esq);
}

int maior(int x, int y)
{
    if (x > y)
        return x;
    else
        return y;
}

// Rotação simples à direita
tipo_no* rotacao_direita(tipo_no* no) {
    tipo_no* no_aux = no->esq;
    no->esq = no_aux->dir;
    no_aux->dir = no;
    // Atualiza alturas e fb
    no->h = 1 + maior(altura_no(no->dir), altura_no(no->esq));
    no->fb = funcao_balanceamento(no);
    no_aux->h = 1 + maior(altura_no(no_aux->dir), altura_no(no_aux->esq));
    no_aux->fb = funcao_balanceamento(no_aux);
    return no_aux;
}

// Rotação simples à esquerda
tipo_no* rotacao_esquerda(tipo_no* no) {
    tipo_no* no_aux = no->dir;
    no->dir = no_aux->esq;
    no_aux->esq = no;
    // Atualiza alturas e fb
    no->h = 1 + maior(altura_no(no->dir), altura_no(no->esq));
    no->fb = funcao_balanceamento(no);
    no_aux->h = 1 + maior(altura_no(no_aux->dir), altura_no(no_aux->esq));
    no_aux->fb = funcao_balanceamento(no_aux);
    return no_aux;
}

// Rotação dupla à direita
tipo_no* rotacao_dupla_direita(tipo_no* no) {
    no->esq = rotacao_esquerda(no->esq);
    return rotacao_direita(no);
}

// Rotação dupla à esquerda
tipo_no* rotacao_dupla_esquerda(tipo_no* no) {
    no->dir = rotacao_direita(no->dir);
    return rotacao_esquerda(no);
}

// Inserção AVL com balanceamento
tipo_no* inserir_no(tipo_no* raiz, char *nome) {
    if (raiz == NULL)
        return aloca_no(nome);

    int result = strcmp(nome, raiz->nome);
    if (result < 0) {
        raiz->esq = inserir_no(raiz->esq, nome);
    } else {
        raiz->dir = inserir_no(raiz->dir, nome);
    }

    // Atualiza altura e fb após possíveis rotações
    raiz->h = 1 + maior(altura_no(raiz->esq), altura_no(raiz->dir));
    raiz->fb = funcao_balanceamento(raiz);

    // Balanceamento
    if (raiz->fb < -1) {
        if (raiz->esq && strcmp(nome, raiz->esq->nome) < 0) {
            return rotacao_direita(raiz);
        } else if (raiz->esq) {
            return rotacao_dupla_direita(raiz);
        }
    } else if (raiz->fb > 1) {
        if (raiz->dir && strcmp(nome, raiz->dir->nome) > 0) {
            return rotacao_esquerda(raiz);
        } else if (raiz->dir) {
            return rotacao_dupla_esquerda(raiz);
        }
    }

    return raiz;
    #ifdef DEBUG    
        printf("Inserido: %s -> Altura: %d | FB: %d\n", raiz->nome, raiz->h, raiz->fb);
    #endif
}

// Busca de um nome na árvore
char* buscar_no(tipo_no* raiz, char *nome) {
    if (raiz == NULL)
        return NULL;

    int result = strcmp(nome, raiz->nome);
    if (result == 0)
        return raiz->nome;
    else if (result < 0)
        return buscar_no(raiz->esq, nome);
    else
        return buscar_no(raiz->dir, nome);
}

// Leitura de arquivo e inserção na árvore
void ler_arquivo(tipo_no** raiz) {
    char linha[256];
    FILE* arquivo = fopen("words.utf-8.txt", "r");
    while (fgets(linha, sizeof(linha), arquivo)) {
        linha[strcspn(linha, "\n")] = '\0'; // Remove '\n'
        *raiz = inserir_no(*raiz, linha);
    }

    fclose(arquivo);
}

// Impressão em ordem para depuração
void em_ordem(tipo_no* raiz) {
    if (raiz != NULL) {
        em_ordem(raiz->esq);
        printf("%s (h=%d, fb=%d)\n", raiz->nome, raiz->h, raiz->fb);
        em_ordem(raiz->dir);
    }
}
