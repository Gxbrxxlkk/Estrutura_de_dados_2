#ifndef __AVL_H__
#define __AVL_H__

// Incluindo bibliotecas necessarias
#include <stdio.h>
#include <stdlib.h> 
#include <string.h>

#define MAX 200

struct No_avl {
    char nome[MAX];
    int h;
    int fb;
    struct No_avl *dir;
    struct No_avl *esq;
};
// Definicao de um tipo para facilitar o uso da estrutura
typedef struct No_avl tipo_no;

// Declaracao das funcoes para manipulacao da arvore AVL
tipo_no* aloca_no(char *nome);

tipo_no* inserir_no(tipo_no*raiz, char *nome);
char* buscar_no(tipo_no*raiz, char *nome);
int altura_no(tipo_no*no);
void ler_arquivo(tipo_no**raiz);
int funcao_balanceamento(tipo_no* no);
tipo_no* rotacao_direita(tipo_no* no);
tipo_no* rotacao_esquerda(tipo_no* no);
tipo_no* rotacao_dupla_direita(tipo_no* no);
tipo_no* rotacao_dupla_esquerda(tipo_no* no);
void em_ordem(tipo_no* raiz);

#endif