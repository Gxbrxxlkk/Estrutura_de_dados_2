#include "avl.h"

int main() {

    tipo_no *avl = NULL;
    printf("inicio\n");
    ler_arquivo(&avl);
    printf("fim\n");
    int altura = altura_no(avl);
    em_ordem(avl);
    printf("Altura arvore = %d\n",altura);
    return 0;
}
